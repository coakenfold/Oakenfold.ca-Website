function setPubSub( PubSub ){
	window.PubSub = PubSub;
}